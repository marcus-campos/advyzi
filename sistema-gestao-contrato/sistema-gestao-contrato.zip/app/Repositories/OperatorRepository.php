<?php

namespace SgcAdmin\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface OperatorRepository
 * @package namespace SgcAdmin\Repositories;
 */
interface OperatorRepository extends RepositoryInterface
{
    //
}
