<?php

namespace SgcAdmin\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface UserRepository
 * @package namespace SgcAdmin\Repositories;
 */
interface UserRepository extends RepositoryInterface
{
    //
}
