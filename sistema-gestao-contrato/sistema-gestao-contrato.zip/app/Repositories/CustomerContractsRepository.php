<?php

namespace SgcAdmin\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface CustomerContractsRepository
 * @package namespace SgcAdmin\Repositories;
 */
interface CustomerContractsRepository extends RepositoryInterface
{
    //
}
