<?php

namespace SgcAdmin\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ContractRepository
 * @package namespace SgcAdmin\Repositories;
 */
interface ContractRepository extends RepositoryInterface
{
    //
}
